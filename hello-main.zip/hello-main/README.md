Follow the QUEEN MAYA MD channel on WhatsApp: https://whatsapp.com/channel/0029VbAEkzNFi8xevDsbJS1L
😊🤭🌝

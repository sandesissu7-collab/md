const { cmd } = require('../command');
const { exec } = require('child_process');
const config = require('../config');
const { getBuffer, getGroupAdmins, getRandom, h2k, isUrl, Json, runtime, sleep, fetchJson} = require('../lib/functions')
// 1. Shutdown Bot
cmd({
    pattern: "shutdown",
    desc: "Shutdown the bot.",
    category: "owner",
    react: "🛑",
    filename: __filename
},
async (conn, mek, m, { from, isOwner, reply }) => {
    if (!isOwner) return reply("❌ You are not the owner!");
    reply("🛑 Shutting down...").then(() => process.exit());
});

// 2. Broadcast Message to All Groups
cmd({
    pattern: "broadcast",
    desc: "Broadcast a message to all groups.",
    category: "owner",
    react: "📢",
    filename: __filename
},
async (conn, mek, m, { from, isOwner, args, reply }) => {
    if (!isOwner) return reply("❌ уσυ αяє ησт тнє σωηєя!");
    if (args.length === 0) return reply("📢 ρℓєαѕє ρяσνι∂є α мєѕѕαgє тσ вяσα∂¢αѕт.");

    const message = args.join(' ');
    const groups = Object.keys(await conn.groupFetchAllParticipating());

    for (const groupId of groups) {
        await conn.sendMessage(groupId, { text: message }, { quoted: mek });
    }

    reply("📢 мєѕѕαgє вяσα∂¢αѕтє∂ тσ αℓℓ gяσυρѕ.");
});

// 3. Set Profile Picture
cmd({
      pattern: "setpp",
      desc: "Set bot profile picture.",
      category: "owner",
      react: "🖼️",
      filename: __filename
  },
  async (conn, msg, m, { from , isOwner, isDev, reply }) => {
    
      if (!isOwner) return reply("❌ You are not the owner!");
  
      const quotedMsg = m.quoted;
  
      if (!quotedMsg || quotedMsg.mtype !== 'imageMessage') {
          return reply("❌ Please reply to an image.");
      }
  
      try {
          const mediaBuffer = await quotedMsg.download() || await conn.downloadMediaMessage(quotedMsg);
  
          if (!mediaBuffer) return reply("❌ Failed to download image.");
  
          const resized = await sharp(mediaBuffer)
              .resize(640, 640)
              .jpeg()
              .toBuffer();
  
          await conn.updateProfilePicture(conn.user.id, resized);
  
          reply("🖼️ Profile picture updated successfully!");
      } catch (error) {
          console.error(err);("Error updating profile picture:", error);
          reply(`❌ Error: ${error.message}`);
      }
  });

cmd(
    {
      pattern: 'block',
      desc: 'Add Sudo Number',
      category: 'owner',
      filename: __filename,
    },
    async (conn, msg , m, { from, reply, isOwner, isDev, isGroup,pushname, q }) => {
		
      if (isGroup) return reply('⚠️ This command can only be used inbox.');
      if (!isOwner) return reply('🚫 Only the bot owner can use this command.');
  
          const targetId = msg.quoted
        ? msg.quoted.key.remoteJid
        : from;
  
      if (!targetId.endsWith('@s.whatsapp.net')) return reply('⚠️ Only User Nembers can block.');
  
      try {
        
        
        const num = q;
        
        const bc = `${num}@s.whatsapp.net`;
        
      const idd = targetId || bc;
        const success = await conn.updateBlockStatus(idd, "block") // Block user
        if (success) {
          reply(`🚫 ${idd} User blocked .`);
        } else {
          reply('❌ Failed to Block .');
        }
      } catch (error) {
        console.error(err);('Error:', error);
      reply('❌ Failed to block.');
      }
    }
  );
  
  
  cmd(
    {
      pattern: 'unblock',
      desc: 'Add Sudo Number',
      category: 'owner',
      filename: __filename,
    },
    async (conn, msg , m, { from, reply, isOwner, isDev, isGroup, pushname, q }) => {

      if (isGroup) return reply('⚠️ This command can only be used inbox.');
      if (!isOwner) return reply('🚫 Only the bot owner can use this command.');
  
          const targetId = msg.quoted
        ? msg.quoted.key.remoteJid
        : from;
  
      if (!targetId.endsWith('@s.whatsapp.net')) return reply('⚠️ Only inboxIDs User blocked.');
  
      try {
        
        const num = q;
        
        const bc = `${num}@s.whatsapp.net`;
        
      const idd = targetId || bc;
        const success = await conn.updateBlockStatus(idd, "unblock") // Block user
        if (success) {
          reply(`💫 ${idd} User unblocked .`)
        } else {
          reply('❌ Failed to unblock .');
        }
      } catch (error) {
        console.error(err);('Error:', error);
       reply('❌ Failed to unblock.');
      }
    }
  );
// 6. Clear All Chats
cmd({
    pattern: "clearchats",
    desc: "Clear all chats from the bot.",
    category: "owner",
    react: "🧹",
    filename: __filename
},
async (conn, mek, m, { from, isOwner, reply }) => {
    if (!isOwner) return reply("❌ уσυ αяє ησт тнє σωηєя!");
    try {
        const chats = conn.chats.all();
        for (const chat of chats) {
            await conn.modifyChat(chat.jid, 'delete');
        }
        reply("🧹 αℓℓ ¢нαтѕ ¢ℓєαяє∂ ѕυ¢¢єѕѕƒυℓℓу!");
    } catch (error) {
        reply(`❌ єяяσя ¢ℓєαяιηg ¢нαтѕ: ${error.message}`);
    }
});

// 7. Get Bot JID
cmd({
    pattern: "jid",
    desc: "Get the bot's JID.",
    category: "owner",
    react: "🤖",
    filename: __filename
},
async (conn, mek, m, { from, isOwner, reply }) => {
    if (!isOwner) return reply("❌ уσυ αяє ησт тнє σωηєя!");
    reply(`🤖 *Bot JID:* ${conn.user.jid}`);
});

// 8. Group JIDs List
cmd({
    pattern: "gjid",
    desc: "Get the list of JIDs for all groups the bot is part of.",
    category: "owner",
    react: "📝",
    filename: __filename
},
async (conn, mek, m, { from, isOwner, reply }) => {
    if (!isOwner) return reply("❌ уσυ αяє ησт тнє σωηєя!");

    const groups = await conn.groupFetchAllParticipating();
    const groupJids = Object.keys(groups).join('\n');
    reply(`📝 *Group JIDs:*\n\n${groupJids}`);
});

const { cmd } = require('../command');
const axios = require('axios');

// GPT Command
cmd({
  pattern: "ai",
  alias: ["bot", "dj", "gpt", "gpt4", "bing"],
  desc: "Chat with an AI model",
  category: "ai",
  react: "🤖",
  filename: __filename
},
async (conn, mek, m, { from, reply, q }) => {
  try {
    if (!q) return reply("Please provide a message for the AI.\nExample: `.ai Hello`");

    const apiUrl = `https://lance-frank-asta.onrender.com/api/gpt?q=${encodeURIComponent(q)}`;
    const { data } = await axios.get(apiUrl);

    if (!data || !data.message) {
      return reply("❌ AI failed to respond. Please try again later.");
    }

    await reply(`🤖 *GPT AI Response:*\n\n${data.message}`);
  } catch (e) {
    console.error("Error in AI command:", e);
    reply("❌ An error occurred while communicating with the AI.");
  }
});


// OpenAI Command
cmd({
  pattern: "openai",
  alias: ["chatgpt", "gpt3", "open-gpt"],
  desc: "Chat with OpenAI",
  category: "ai",
  react: "🧠",
  filename: __filename
},
async (conn, mek, m, { from, reply, q }) => {
  try {
    if (!q) return reply("Please provide a message for OpenAI.\nExample: `.openai Hello`");

    const apiUrl = `https://vapis.my.id/api/openai?q=${encodeURIComponent(q)}`;
    const { data } = await axios.get(apiUrl);

    if (!data || !data.result) {
      return reply("❌ OpenAI failed to respond. Please try again later.");
    }

    await reply(`🧠 *OpenAI Response:*\n\n${data.result}`);
  } catch (e) {
    console.error("Error in OpenAI command:", e);
    reply("❌ An error occurred while communicating with OpenAI.");
  }
});


// DeepSeek Command
cmd({
  pattern: "deepseek",
  alias: ["deep", "seekai"],
  desc: "Chat with DeepSeek AI",
  category: "ai",
  react: "🧠",
  filename: __filename
},
async (conn, mek, m, { from, reply, q }) => {
  try {
    if (!q) return reply("Please provide a message for DeepSeek AI.\nExample: `.deepseek Hello`");

    const apiUrl = `https://api.ryzendesu.vip/api/ai/deepseek?text=${encodeURIComponent(q)}`;
    const { data } = await axios.get(apiUrl);

    if (!data || !data.answer) {
      return reply("❌ DeepSeek AI failed to respond. Please try again later.");
    }

    await reply(`🧠 *DeepSeek AI Response:*\n\n${data.answer}`);
  } catch (e) {
    console.error("Error in DeepSeek command:", e);
    reply("❌ An error occurred while communicating with DeepSeek AI.");
  }
});